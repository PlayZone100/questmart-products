CREATOR COMMAND CENTER  v1.1.0
==============================

One idea to eight platforms, plan your posts, price your deals, track your
income, edit photos and video, and build your media kit and link page.
It is a single HTML file. It works offline and your data stays in your browser.


QUICK START
-----------
1. Unzip this folder.
2. Open creator-command-center.html in Chrome, Edge or Firefox.
   (Double-click it, or upload it to your own website and open that URL.)
3. Read the Help tab inside the tool for a short walkthrough.

Nothing to install. No account. No server.


WHAT'S INSIDE THE TOOL
----------------------
Repurpose   One topic in, drafts for X, Instagram, TikTok, YouTube, Telegram,
            LinkedIn, Threads and Pinterest. "Add all 8 to calendar" schedules
            them in one click.
Ideas       An idea bank. Send any idea straight into Repurpose.
Calendar    Track what is posted where. Shows your current posting streak.
Deals       Sponsorship rate estimator, brand pitch email writer, and a deal
            pipeline (Contacted, Negotiating, Confirmed, Declined, Paid).
Income      Log payments by source and platform, see totals, set aside a
            percentage for taxes, export to CSV.
Studio      Resize photos and video for each platform, add text and your logo,
            adjust the look, trim video, add music, remove photo backgrounds,
            auto-generate captions.
Media Kit   Download a one-page media kit (.html) or print it to PDF.
Link Page   Build a link-in-bio page and download it as a standalone .html file.


BACK UP YOUR DATA (IMPORTANT)
-----------------------------
Your calendar, ideas, deals, income, tax percentage and watermark are saved in
this browser only. If you clear your browser history or switch devices, they
will not follow you.

- Click "Export all data (.json)" at the top of the page regularly.
- Click "Import backup" to restore it on this device or a new one.


GOOD TO KNOW
------------
- Video export uses your browser's built-in recorder. It works in current
  Chrome, Edge and Firefox. Safari and iPhone may not support it. Export runs
  in real time (a 30-second clip takes about 30 seconds) and the tab must stay
  open and visible.
- Background removal and auto-captions download an AI model of about 40 MB the
  first time you use them, so you need internet for that moment. After that
  they are cached and work offline. Some school and office networks block the
  download. Try another network if it keeps failing.
- "Write with AI" is optional. You paste your own Claude API key, your text is
  sent directly to Anthropic, and usage is billed to your own Anthropic
  account. The key is stored only in your browser. The regular draft generator
  works without it.
- The rate estimator is a starting point, not a market benchmark. The tax
  set-aside is a planning number, not tax advice.


PUBLISHING YOUR MEDIA KIT AND LINK PAGE
---------------------------------------
Both tools download a complete, self-contained .html file.
To get a real URL, upload the file to any host. For example, put it in a
folder of your GitHub Pages site (such as /links/index.html).


LICENSE
-------
See LICENSE.txt. In short: for your own creator business, on your own devices.
Please do not resell or redistribute the file.
