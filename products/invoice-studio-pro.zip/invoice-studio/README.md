# Invoice Studio

A single-file, offline invoicing desk. Create invoices, quotes and receipts, print them to PDF, and keep everything on your own computer. No account, no subscription, no server.

## Quick start

1. Unzip this folder anywhere.
2. Double-click `invoice-studio.html`. It opens in your default browser.
3. Fill in your business details once (they are remembered for next time).
4. Add a client and your line items.
5. Press **Print / PDF** and choose "Save as PDF" as the destination.

That is the whole setup. There is nothing to install and no build step.

## What is inside

| File | Purpose |
|------|---------|
| `invoice-studio.html` | The app. One self-contained file. |
| `README.md` | This guide. |
| `LICENSE.txt` | Licence terms. |
| `CHANGELOG.md` | Version history. |

## Features

- Three document types: invoice, quote and receipt, with automatic numbering (INV / QTE / RCP).
- 69 currencies, including six crypto assets (BTC, ETH, USDT, USDC, SOL, XMR).
- Crypto wallet addresses printed as selectable text, so clients can copy them from the PDF.
- Bank or transfer instructions block.
- Seven document languages: English, Spanish, French, German, Portuguese, Arabic and Persian, with right-to-left layout for Arabic and Persian.
- Tax: none, one rate on everything, or per line item. Prices can be tax-exclusive or tax-inclusive.
- Percentage or fixed discounts, shipping/fees, and amount already paid (shows the balance due).
- Four templates (Classic, Modern, Compact, Typed) and eight accent colours.
- Optional logo, stored on your device.
- Saved clients, saved documents, duplicate-as-new-draft, and a "PAID" stamp.
- Drag-and-drop line reordering.
- Works on phones and tablets as well as desktops.
- Export and import full backups (JSON) and export your document list as CSV.

## Where your data lives

Everything is stored in your browser's local storage on the device you use. Nothing is uploaded anywhere, and the app makes no network requests.

Because of this:

- **Export a backup** (Backup section in the side panel) before clearing your browser data, reinstalling your browser, or switching computers.
- Data saved in one browser is not visible in another browser or on another device. Use Export / Import to move it.
- Opening the file from a different folder or path can be treated as a different site by some browsers, which means saved data may not appear. Keep the file in one place, or import a backup.

## Tips

- **Ctrl/Cmd + S** saves the current document.
- For clean PDFs, in the print dialog turn off "Headers and footers" and turn on "Background graphics".
- The page is A4. Most printers and PDF viewers scale it to Letter automatically. Choose "Fit to page" if yours does not.
- To reuse a document, open **Saved** and press **Duplicate**.

## Customising

The whole app is one HTML file with the styles at the top and the script at the bottom. Open it in any text editor.

- Currencies: edit the `CURRENCIES` list.
- Languages and labels: edit the `LANGS` object.
- Colours: edit the `ACCENTS` list and the variables at the top of the stylesheet.

## Support

Questions or problems: https://questmart.online
