# Changelog

## 1.0 — Initial release

- Invoices, quotes and receipts with automatic numbering.
- 69 currencies including BTC, ETH, USDT, USDC, SOL and XMR.
- Crypto wallet and bank payment blocks.
- Seven document languages with right-to-left support (Arabic, Persian).
- Single-rate or per-line tax, tax-inclusive pricing, discounts, shipping, partial payments.
- Four templates, eight accent colours, optional logo, "PAID" stamp.
- Saved clients and documents, duplicate as draft.
- JSON backup and import, CSV export of the document list.
- Print / Save as PDF on A4.
- Fully offline: no account, no network requests, data stays in your browser.
