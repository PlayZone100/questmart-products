# Meridian — SaaS Product Launch Landing Page

A single-file, self-contained landing page template for a SaaS / dev-tools
product. Dark, editorial-toned design (deep forest-black, warm brass
accent, serif display type) — built to stand out from typical
card-and-gradient SaaS templates.

## What's inside

- `index.html` — the entire page (HTML + CSS, no build step, no
  external JS libraries). Fonts load from Google Fonts.

## How to make it yours

Everything you'll want to change lives in plain text inside
`index.html` — open it in any text editor and use Find & Replace.

1. **Brand name** — replace every instance of "Meridian" (nav, footer,
   hero panel label).
2. **Headline & copy** — the hero headline, subheading, feature
   descriptions, testimonial, and pricing copy are all placeholder
   content written for a dev-tools product. Rewrite them for your own
   product; keep sentences short the way the original does.
3. **Colors** — all colors are CSS variables at the very top of the
   `<style>` block (`--bg`, `--accent`, `--teal`, etc.). Change the
   values there and the whole page updates.
4. **Logo mark** — the small triangle-mountain icon in the nav is
   inline SVG right after `<div class="brand">`. Swap it for your own
   logo SVG or an `<img>` tag.
5. **Links & buttons** — every `<a href="#">` is a placeholder. Point
   them at your real sign-up page, docs, etc.
6. **Pricing** — the three pricing columns are plain HTML in the
   `#pricing` section; add, remove, or relabel columns as needed.

The layout is responsive down to mobile out of the box, and the nav
already collapses its links on narrow screens.

## License

Personal and commercial use for a single end product (your own site,
or one client site per license) is fine. You may not resell,
redistribute, or re-publish this template itself — as a template,
theme, or stock asset — to a third party.

## Support

This is a self-serve template with no included support. If a section
doesn't render as expected, check that the two Google Fonts links in
`<head>` are reachable (some corporate networks block Google Fonts;
swap in a system font stack in that case).
